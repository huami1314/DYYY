#import <UIKit/UIViewController.h>

@class NSString;

@interface MMWebViewController: UIViewController
{
}
- (id)initWithURL:(id)arg1 presentModal:(BOOL)arg2 extraInfo:(id)arg3;
@end
