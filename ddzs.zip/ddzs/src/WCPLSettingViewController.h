//
// WCPLSettingViewController.h
//
// Created by dyf on 17/4/6.
// Copyright © 2017 dyf. All rights reserved.
//

#import "WCPLBaseViewController.h"

@interface WCPLSettingViewController : WCPLBaseViewController
@end
